export { default } from "./MainQuiz1";
